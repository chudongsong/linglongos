# 玲珑OS双因子认证登录页面设计

## 概述

本设计文档基于现有的Google Authenticator双因子认证登录页面设计，结合玲珑OS项目的技术栈和架构特点，进行了针对性的优化和改进。该设计将双因子认证登录页面完全融入到玲珑OS的桌面环境中，提供一致的用户体验和技术架构。

### 核心特性
- 与玲珑OS桌面环境深度集成
- 基于自研UI组件库的统一设计语言
- 符合玲珑OS架构模式的组件设计
- 支持窗口化显示和嵌入式集成
- Vue Router 4 路由管理
- Pinia状态管理集成

## 技术栈与依赖

### 前端框架
- **Vue 3** - 主要前端框架 (v3.5.18+)
- **TypeScript** - 类型安全 (v5.8.3+)
- **Vue Router 4** - 路由管理
- **Vite** - 构建工具
- **Pinia** - 状态管理

### UI组件库
- **@linglongos/ui** - 玲珑OS自研UI组件库
- **UnoCSS** - 原子化CSS框架（仅限组件库内部使用）
- **@linglongos/shared-types** - 共享类型定义

### 双因子认证相关
- **qrcode** - QR码生成 (v1.5.4)
- **otpauth** - OTP密钥生成与验证 (v9.4.1)
- **crypto-js** - 加密处理 (v4.2.0)
- **@vueuse/core** - Vue组合式工具库 (v13.9.0)

### 图标库
- **lucide-vue-next** - 图标组件 (v0.544.0)

## 组件架构

### 组件层次结构

系统采用符合玲珑OS架构模式的层次化组件架构：

```mermaid
graph TB
    A[AuthApp 认证应用] --> B[AuthLayout 认证布局]
    B --> C[LoginWindow 登录窗口]
    C --> D[LoginForm 登录表单]
    C --> E[SetupModal 设置模态框]
    D --> F[LInput 输入组件]
    D --> G[LButton 按钮组件]
    E --> H[QRCodeDisplay 二维码显示]
    E --> I[LCard 卡片组件]
    
    J[AuthStore 认证状态] --> C
    K[UIStore 界面状态] --> C
```

### 核心组件定义

#### 认证应用组件 (AuthApp)
- **职责**: 作为独立应用的根组件，管理全局认证状态
- **特点**: 可以作为桌面应用或嵌入式组件运行
- **集成**: 符合玲珑OS应用注册机制

#### 认证布局组件 (AuthLayout)
- **职责**: 提供统一的认证界面布局框架
- **特点**: 支持窗口化和全屏模式
- **样式**: 使用@linglongos/ui组件库的布局组件

#### 登录窗口组件 (LoginWindow)
- **职责**: 主要的登录界面容器
- **特点**: 支持窗口系统集成，可拖拽、缩放
- **状态**: 管理登录流程和2FA设置状态

#### 登录表单组件 (LoginForm)
- **职责**: 用户名和验证码输入表单
- **组件**: 使用LInput、LButton等自研组件
- **验证**: 集成表单验证和错误处理

#### 设置模态框组件 (SetupModal)
- **职责**: 2FA初始化设置界面
- **组件**: 使用LModal、LCard等组件
- **功能**: 二维码生成、密钥显示、验证确认

## 状态管理架构

### 认证状态管理 (AuthStore)

```typescript
interface AuthState {
  // 用户认证状态
  isAuthenticated: boolean
  currentUser: User | null
  
  // 2FA配置状态
  is2FAEnabled: boolean
  setupPhase: '2fa-check' | '2fa-setup' | '2fa-verify' | 'login-success'
  
  // 登录尝试控制
  loginAttempts: number
  lastAttemptTime: number
  isLocked: boolean
  
  // 配置信息
  userSecrets: Map<string, string>
  qrCodeUrl: string
  manualKey: string
}

interface AuthActions {
  // 登录相关
  login(username: string, otp?: string): Promise<boolean>
  logout(): void
  
  // 2FA管理
  check2FAStatus(username: string): Promise<boolean>
  setup2FA(username: string): Promise<{ qrCode: string; secret: string }>
  verify2FASetup(username: string, otp: string): Promise<boolean>
  
  // 安全控制
  recordFailedAttempt(): void
  resetAttempts(): void
  checkLockStatus(): boolean
}
```

### UI状态管理 (UIStore)

```typescript
interface UIState {
  // 界面显示状态
  showSetupModal: boolean
  showQRCode: boolean
  currentTab: 'qr' | 'manual'
  
  // 加载状态
  isLoading: boolean
  isVerifying: boolean
  
  // 错误处理
  errorMessage: string
  showError: boolean
  
  // 窗口状态
  windowConfig: WindowConfig
  isWindowMode: boolean
}
```

## 数据流架构

### 认证流程图

```mermaid
graph TD
    A[用户输入用户名] --> B{检查2FA状态}
    B -->|未设置| C[显示2FA设置模态框]
    B -->|已设置| D[显示OTP输入框]
    
    C --> E[生成密钥和二维码]
    E --> F[用户设置认证器]
    F --> G[输入验证码确认]
    G --> H{验证成功?}
    H -->|是| I[保存配置]
    H -->|否| J[显示错误信息]
    
    D --> K[输入OTP验证码]
    K --> L{验证OTP}
    L -->|成功| M[登录成功]
    L -->|失败| N[记录失败次数]
    N --> O{达到限制?}
    O -->|是| P[锁定账户]
    O -->|否| D
    
    I --> D
    M --> Q[跳转到桌面]
```

### 组件通信模式

```mermaid
graph LR
    A[LoginForm] -->|用户事件| B[AuthStore]
    B -->|状态变更| C[LoginWindow]
    C -->|UI更新| D[SetupModal]
    
    E[WindowSystem] -->|窗口事件| F[UIStore]
    F -->|界面状态| C
    
    G[EventBus] -->|全局事件| B
    B -->|认证事件| G
```

## 路由与导航

### 路由结构

基于Vue Router 4的路由配置：

```typescript
const routes = [
  {
    path: '/',
    redirect: '/auth/login'
  },
  {
    path: '/auth',
    component: AuthLayout,
    children: [
      {
        path: 'login',
        name: 'Login',
        component: LoginWindow,
        meta: { requiresAuth: false }
      }
    ]
  },
  {
    path: '/desktop',
    name: 'Desktop',
    component: () => import('@/views/Desktop.vue'),
    meta: { requiresAuth: true }
  }
]
```

### 导航守卫

```typescript
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next('/auth/login')
  } else if (to.path === '/auth/login' && authStore.isAuthenticated) {
    next('/desktop')
  } else {
    next()
  }
})
```

## 样式设计

### 设计系统

采用玲珑OS统一设计语言：

| 设计元素 | 规范 | 说明 |
|----------|------|------|
| **颜色方案** | 主色调: #1890ff, 辅助色: #52c41a | 与桌面系统保持一致 |
| **字体系统** | Inter, PingFang SC, sans-serif | 现代化可读性字体 |
| **间距系统** | 4px基准，8、12、16、24、32倍数 | 统一的间距规律 |
| **圆角设计** | 4px、8px、12px | 现代圆润风格 |
| **阴影效果** | 多层次阴影系统 | 增强层次感 |

### 组件样式规范

```typescript
// 使用@linglongos/ui组件，避免直接使用原子化CSS
<template>
  <l-card class="auth-card">
    <l-form @submit="handleSubmit">
      <l-input 
        v-model="username" 
        placeholder="用户名"
        type="text"
        :error="usernameError"
      />
      <l-button 
        type="primary" 
        :loading="isLoading"
        block
      >
        登录
      </l-button>
    </l-form>
  </l-card>
</template>
```

### 响应式设计

| 断点 | 屏幕尺寸 | 布局特点 |
|------|----------|----------|
| **mobile** | < 768px | 全屏布局，简化交互 |
| **tablet** | 768px - 1024px | 居中卡片，适中尺寸 |
| **desktop** | > 1024px | 窗口化显示，完整功能 |

## API 集成层

### 认证服务接口

```typescript
interface AuthService {
  // 用户认证
  checkUserExists(username: string): Promise<boolean>
  
  // 2FA管理
  get2FAStatus(username: string): Promise<{ enabled: boolean }>
  setup2FA(username: string): Promise<{ secret: string; qrCode: string }>
  verify2FA(username: string, token: string): Promise<{ valid: boolean }>
  
  // 登录验证
  login(username: string, token: string): Promise<{ success: boolean; token?: string }>
}
```

### 适配器模式实现

```typescript
// 基础适配器接口
interface AuthAdapter {
  authenticate(credentials: AuthCredentials): Promise<AuthResult>
  setup2FA(userId: string): Promise<Setup2FAResult>
  verify2FA(userId: string, token: string): Promise<boolean>
}

// 宝塔面板适配器
class BaotaAuthAdapter implements AuthAdapter {
  // 实现具体的宝塔API调用
}

// 1Panel适配器
class OnePanelAuthAdapter implements AuthAdapter {
  // 实现具体的1Panel API调用
}
```

## 错误处理与用户反馈

### 错误类型定义

```typescript
enum AuthErrorType {
  INVALID_USERNAME = 'invalid_username',
  INVALID_OTP = 'invalid_otp',
  SETUP_FAILED = 'setup_failed',
  NETWORK_ERROR = 'network_error',
  ACCOUNT_LOCKED = 'account_locked',
  RATE_LIMITED = 'rate_limited'
}

interface AuthError {
  type: AuthErrorType
  message: string
  details?: any
  timestamp: number
}
```

### 用户反馈机制

```typescript
// 使用@linglongos/ui的通知组件
import { LToast, LNotification } from '@linglongos/ui'

// 错误提示
LToast.error('用户名或验证码错误')

// 成功提示
LToast.success('登录成功')

// 信息通知
LNotification.info({
  title: '设置提醒',
  message: '请使用认证器扫描二维码'
})
```

## 安全性考虑

### 前端安全措施

| 安全措施 | 实现方式 | 说明 |
|----------|----------|------|
| **输入验证** | 正则表达式 + 长度限制 | 防止注入攻击 |
| **密钥加密** | crypto-js + 设备指纹 | 本地存储加密 |
| **失败限制** | 时间窗口 + 计数器 | 防止暴力破解 |
| **会话管理** | JWT + 过期检查 | 安全的会话控制 |

### 数据保护

```typescript
// 密钥加密存储
import CryptoJS from 'crypto-js'

class SecureStorage {
  private getDeviceFingerprint(): string {
    // 生成设备指纹
    return CryptoJS.MD5(navigator.userAgent + screen.width + screen.height).toString()
  }
  
  encryptAndStore(key: string, data: string): void {
    const fingerprint = this.getDeviceFingerprint()
    const encrypted = CryptoJS.AES.encrypt(data, fingerprint).toString()
    localStorage.setItem(key, encrypted)
  }
  
  decryptAndRetrieve(key: string): string | null {
    const encrypted = localStorage.getItem(key)
    if (!encrypted) return null
    
    try {
      const fingerprint = this.getDeviceFingerprint()
      const decrypted = CryptoJS.AES.decrypt(encrypted, fingerprint)
      return decrypted.toString(CryptoJS.enc.Utf8)
    } catch {
      return null
    }
  }
}
```

## 性能优化

### 代码分割策略

```typescript
// 路由级别的代码分割
const AuthModule = () => import('@/modules/auth/AuthModule.vue')
const SetupModal = defineAsyncComponent(() => import('@/components/SetupModal.vue'))

// 组件级别的懒加载
const QRCodeGenerator = defineAsyncComponent({
  loader: () => import('@/components/QRCodeGenerator.vue'),
  loadingComponent: LoadingSpinner,
  delay: 200
})
```

### 资源优化

| 优化项 | 实现方式 | 效果 |
|--------|----------|------|
| **图片优化** | WebP格式 + 懒加载 | 减少资源大小 |
| **防抖处理** | @vueuse/core debounce | 减少API调用 |
| **缓存策略** | QR码本地缓存 | 提升用户体验 |
| **预加载** | 关键组件预加载 | 减少等待时间 |

## 窗口系统集成

### 窗口配置

```typescript
const authWindowConfig: WindowConfig = {
  title: '用户登录',
  appId: 'auth-login',
  size: { width: 400, height: 500 },
  minSize: { width: 350, height: 450 },
  center: true,
  resizable: false,
  modal: true,
  icon: 'lock'
}
```

### 窗口生命周期

```typescript
// 窗口创建
const windowStore = useWindowStore()
const authWindow = windowStore.createWindow(authWindowConfig)

// 窗口事件处理
authWindow.on('close', () => {
  // 清理认证状态
  authStore.resetState()
})

authWindow.on('minimize', () => {
  // 暂停定时器等
})
```

## 测试策略

### 单元测试

```typescript
// 认证状态测试
describe('AuthStore', () => {
  test('should handle login flow correctly', async () => {
    const store = useAuthStore()
    await store.login('testuser', '123456')
    expect(store.isAuthenticated).toBe(true)
  })
  
  test('should lock account after failed attempts', () => {
    const store = useAuthStore()
    // 模拟多次失败登录
    for (let i = 0; i < 5; i++) {
      store.recordFailedAttempt()
    }
    expect(store.isLocked).toBe(true)
  })
})

// 组件测试
describe('LoginForm', () => {
  test('should validate user input', async () => {
    const wrapper = mount(LoginForm)
    await wrapper.find('input[name="username"]').setValue('')
    await wrapper.find('form').trigger('submit')
    expect(wrapper.find('.error-message').text()).toContain('用户名不能为空')
  })
})
```

### 集成测试

```typescript
// E2E测试 (Playwright)
test('complete 2FA login flow', async ({ page }) => {
  await page.goto('/auth/login')
  
  // 输入用户名
  await page.fill('[data-testid="username-input"]', 'testuser')
  await page.click('[data-testid="next-button"]')
  
  // 检查是否显示2FA设置
  await expect(page.locator('[data-testid="setup-modal"]')).toBeVisible()
  
  // 完成2FA设置流程
  await page.click('[data-testid="setup-complete"]')
  
  // 验证跳转到桌面
  await expect(page).toHaveURL('/desktop')
})
```

## 项目集成与部署

### Monorepo集成

```json
{
  "name": "@linglongos/auth-2fa",
  "version": "1.0.0",
  "dependencies": {
    "@linglongos/ui": "workspace:*",
    "@linglongos/shared-types": "workspace:*",
    "@linglongos/utils": "workspace:*",
    "vue": "^3.5.18",
    "pinia": "^3.0.3",
    "vue-router": "^4.5.1",
    "@vueuse/core": "^13.9.0",
    "qrcode": "^1.5.4",
    "otpauth": "^9.4.1",
    "crypto-js": "^4.2.0",
    "lucide-vue-next": "^0.544.0"
  }
}
```

### 目录结构

```
apps/auth-2fa/
├── src/
│   ├── components/           # 组件目录
│   │   ├── forms/           # 表单组件
│   │   │   ├── LoginForm.vue
│   │   │   └── SetupForm.vue
│   │   ├── modals/          # 模态框组件
│   │   │   └── SetupModal.vue
│   │   └── ui/              # UI基础组件
│   ├── views/               # 页面组件
│   │   ├── AuthLayout.vue
│   │   └── LoginWindow.vue
│   ├── stores/              # Pinia状态管理
│   │   ├── auth.ts
│   │   └── ui.ts
│   ├── services/            # 服务层
│   │   ├── auth.service.ts
│   │   ├── crypto.service.ts
│   │   └── adapters/
│   ├── router/              # 路由配置
│   │   └── index.ts
│   ├── types/               # 类型定义
│   │   └── auth.ts
│   ├── utils/               # 工具函数
│   │   └── validation.ts
│   ├── App.vue              # 主应用组件
│   └── main.ts              # 入口文件
├── test/                    # 测试文件
│   ├── unit/
│   └── e2e/
├── package.json             # 项目依赖
├── vite.config.ts           # Vite 配置
├── tsconfig.json            # TypeScript 配置
└── README.md                # 项目说明
```

### 构建配置

```typescript
// vite.config.ts
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
      '@linglongos/ui': resolve(__dirname, '../../packages/ui/src'),
      '@linglongos/shared-types': resolve(__dirname, '../../packages/shared-types/src')
    }
  },
  build: {
    lib: {
      entry: resolve(__dirname, 'src/index.ts'),
      name: 'Auth2FA',
      fileName: 'auth-2fa'
    },
    rollupOptions: {
      external: ['vue', 'pinia', 'vue-router'],
      output: {
        globals: {
          vue: 'Vue',
          pinia: 'Pinia',
          'vue-router': 'VueRouter'
        }
      }
    }
  }
})
```